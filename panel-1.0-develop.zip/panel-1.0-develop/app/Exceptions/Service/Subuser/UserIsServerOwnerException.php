<?php

namespace Pterodactyl\Exceptions\Service\Subuser;

use Pterodactyl\Exceptions\DisplayException;

class UserIsServerOwnerException extends DisplayException
{
}
